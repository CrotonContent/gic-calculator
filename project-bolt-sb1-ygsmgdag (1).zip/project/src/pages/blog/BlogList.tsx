import React from 'react';
import { Link } from 'react-router-dom';
import { format } from 'date-fns';
import { useQuery } from '../../hooks/useQuery';
import { supabase } from '../../lib/supabase';
import type { Database } from '../../types/supabase';

type Post = Database['public']['Tables']['posts']['Row'];

const BlogList: React.FC = () => {
  const { data: posts, isLoading, error } = useQuery<Post[]>(
    async () => {
      const { data, error } = await supabase
        .from('posts')
        .select('*')
        .eq('published', true)
        .order('published_at', { ascending: false });

      if (error) throw error;
      return data;
    }
  );

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center text-red-600 py-8">
        An error occurred while loading posts.
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Blog</h1>
      <div className="grid gap-8">
        {posts?.map((post) => (
          <article key={post.id} className="bg-white rounded-lg shadow-md overflow-hidden">
            {post.featured_image && (
              <img
                src={post.featured_image}
                alt={post.title}
                className="w-full h-48 object-cover"
              />
            )}
            <div className="p-6">
              <Link to={`/blog/${post.slug}`} className="block">
                <h2 className="text-2xl font-bold text-gray-900 hover:text-blue-600 transition-colors mb-2">
                  {post.title}
                </h2>
              </Link>
              <time className="text-sm text-gray-500 mb-4 block">
                {format(new Date(post.published_at || post.created_at), 'MMMM d, yyyy')}
              </time>
              {post.excerpt && (
                <p className="text-gray-600 mb-4">{post.excerpt}</p>
              )}
              <Link
                to={`/blog/${post.slug}`}
                className="text-blue-600 hover:text-blue-800 font-medium"
              >
                Read more →
              </Link>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
};

export default BlogList;