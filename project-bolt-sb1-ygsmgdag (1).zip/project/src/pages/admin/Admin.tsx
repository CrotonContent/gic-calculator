import React from 'react';

const Admin: React.FC = () => {
  return (
    <div style={{ width: '100%', height: '100vh' }}>
      <iframe
        src="/admin/index.html"
        style={{ width: '100%', height: '100%', border: 'none' }}
        title="Content Manager"
      />
    </div>
  );
};

export default Admin;