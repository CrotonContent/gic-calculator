// Only import CMS in the browser
let CMS: any;

if (typeof window !== 'undefined') {
  import('decap-cms-app').then((module) => {
    CMS = module.default;
    
    // Custom backend implementation for Supabase
    const SupabaseBackend = {
      init: () => ({
        async login() {
          return true;
        },
        async getEntry(path: string) {
          const { data, error } = await supabase
            .from('posts')
            .select('*')
            .eq('slug', path)
            .single();

          if (error) throw error;
          return data;
        },
        async persistEntry(entry: any) {
          const { error } = await supabase
            .from('posts')
            .upsert({
              title: entry.title,
              slug: entry.slug,
              content: entry.content,
              excerpt: entry.excerpt,
              published: entry.published,
              published_at: entry.published_at,
              featured_image: entry.featured_image,
              meta_title: entry.meta_title,
              meta_description: entry.meta_description,
              author_id: (await supabase.auth.getUser()).data.user?.id
            });

          if (error) throw error;
          return entry;
        },
        async getMedia() {
          return [];
        },
        async persistMedia(file: File) {
          const { data, error } = await supabase.storage
            .from('blog-images')
            .upload(`${Date.now()}-${file.name}`, file);

          if (error) throw error;
          return data;
        }
      })
    };

    // Register the custom backend
    CMS.registerBackend('supabase', SupabaseBackend);
  });
}

export default CMS;